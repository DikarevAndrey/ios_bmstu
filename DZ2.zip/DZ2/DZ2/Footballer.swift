//
//  Footballer.swift
//  DZ2
//
//  Created by Andrey Dikarev on 21/10/2018.
//  Copyright © 2018 Andrey Dikarev. All rights reserved.
//

import Foundation
import UIKit

final class Footballer {
    var id: Int
    var image: UIImage
    var name: String
    var team: String
    var rating: Int
    
    init(id: Int, image: UIImage, name: String, team: String, rating: Int) {
        self.id = id
        self.image = image
        self.name = name
        self.team = team
        self.rating = rating
    }
}
